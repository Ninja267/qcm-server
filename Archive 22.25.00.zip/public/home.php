<?php
// public/home.php
header('Location: index.php?page=login');
exit;